package com.klu.pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPa1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentPa1Application.class, args);
	}

}
