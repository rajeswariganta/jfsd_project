package com.klu.pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentPa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
